# Box's M-test for Homogeneity of Covariance Matrices
# CORRECTED VERSION - handles singular covariance matrices

#' Box's M-test
#' 
#' `boxM` performs the Box's (1949) M-test for homogeneity of covariance
#' matrices obtained from multivariate normal data according to one or more
#' classification factors.

boxM <- function(Y, ...) {
  UseMethod("boxM")
}

boxM.formula <- function(formula, data, ...) {
  form <- as.character(formula)
  if (form[1] != "~" || length(form) != 2)
    stop("Formula must be one-sided.")
  
  Y <- as.matrix(data[, all.vars(formula[[2]])])
  group <- interaction(data[, all.vars(formula[[3]])])
  boxM.default(Y, group, ...)
}

boxM.lm <- function(Y, ...) {
  if (!inherits(Y, "lm"))
    stop(deparse(substitute(Y)), " must be a 'lm' object")
  
  Y <- model.frame(Y)
  factors <- attr(terms(Y), "factors")
  res.terms <- rownames(factors)[apply(factors, 1, sum) == 0]
  group <- interaction(Y[, colnames(factors), drop = FALSE])
  
  Y <- as.matrix(Y[, res.terms])
  boxM.default(Y, group, ...)
}

boxM.default <- function(Y, group, ...) {
  if (!is.matrix(Y))
    Y <- as.matrix(Y)
  
  dname <- paste(deparse(substitute(Y)), "by", deparse(substitute(group)))
  
  # Check for missing data
  na_rows <- apply(is.na(Y), 1, any)
  if (any(na_rows)) {
    warning(sum(na_rows), " cases with missing data have been removed.")
    Y <- Y[!na_rows, , drop = FALSE]
    group <- group[!na_rows]
  }
  
  group <- as.factor(as.character(group))
  nlev <- nlevels(group)
  lev <- levels(group)
  
  # Sample sizes
  n <- table(group)
  N <- nrow(Y)
  p <- ncol(Y)
  
  # Degrees of freedom for each group
  dfs <- n - 1
  
  # Compute covariance matrix for each group
  mats <- aux <- list()
  for (i in 1:nlev) {
    mats[[i]] <- cov(Y[group == lev[i], , drop = FALSE])
    aux[[i]] <- mats[[i]] * dfs[i]
  }
  names(mats) <- lev
  
  # Pooled covariance matrix
  pooled <- Reduce("+", aux) / sum(dfs)
  
  # CORRECTED: Identify groups with singular covariance matrices
  # A group has singular cov matrix if dfs[i] < p (i.e., n[i] <= p)
  singular <- dfs < p
  
  if (any(singular)) {
    singular_groups <- lev[singular]
    warning("Groups ", paste(singular_groups, collapse = ", "), 
            " have fewer observations than variables (n <= p) ",
            "and have been excluded from the calculations.")
  }
  
  # Use only non-singular groups for calculations
  valid_idx <- !singular
  dfs_valid <- dfs[valid_idx]
  nlev_valid <- sum(valid_idx)
  
  # CORRECTED: Calculate logdet, minus2logM, and sum1 using only valid groups
  logdet_all <- rep(-Inf, nlev)  # Initialize with -Inf for all groups
  if (nlev_valid > 0) {
    # Compute log determinants only for valid groups
    logdet_valid <- log(sapply(mats[valid_idx], det))
    logdet_all[valid_idx] <- logdet_valid
    
    # Test statistic using only valid groups
    minus2logM <- sum(dfs_valid) * log(det(pooled)) - sum(logdet_valid * dfs_valid)
    sum1 <- sum(1 / dfs_valid)
  } else {
    # All groups are singular
    minus2logM <- NA
    sum1 <- NA
  }
  names(logdet_all) <- lev
  
  # Correction factors using valid groups only
  Co <- (((2 * p^2) + (3 * p) - 1) / (6 * (p + 1) * (nlev_valid - 1))) *
    (sum1 - (1 / sum(dfs_valid)))
  
  # Test statistic
  X2 <- minus2logM * (1 - Co)
  dfchi <- (choose(p, 2) + p) * (nlev_valid - 1)
  pval <- pchisq(X2, dfchi, lower.tail = FALSE)
  
  # Return as both htest and boxM object
  result <- list(
    statistic = c("Chi-Sq (approx.)" = X2),
    parameter = c(df = dfchi),
    p.value = pval,
    cov = mats,
    pooled = pooled,
    logDet = logdet_all,
    data.name = dname,
    method = "Box's M-test for Homogeneity of Covariance Matrices"
  )
  
  class(result) <- c("boxM", "htest")
  result
}

# Print method
print.boxM <- function(x, ...) {
  cat("\n", x$method, "\n\n")
  cat("data: ", x$data.name, "\n")
  out <- character()
  out <- c(out, paste(names(x$statistic), "=",
                      format(round(x$statistic, 4))))
  out <- c(out, paste(names(x$parameter), "=",
                      format(round(x$parameter, 3))))
  fp <- format.pval(x$p.value, digits = max(1, getOption("digits") - 3))
  out <- c(out, paste("p-value =", fp))
  cat(strwrap(paste(out, collapse = ", ")), sep = "\n")
  cat("\n")
  invisible(x)
}

# Summary method
summary.boxM <- function(object, digits = getOption("digits") - 2, 
                         cov = FALSE, quiet = FALSE, ...) {
  eigs <- lapply(object$cov, eigen, only.values = TRUE)
  eigs <- lapply(eigs, "[[", "values")
  names(eigs) <- names(object$cov)
  
  eigstats <- data.frame(
    product = sapply(eigs, prod),
    sum = sapply(eigs, sum),
    precision = sapply(eigs, function(x) max(x) / min(x)),
    max = sapply(eigs, max),
    min = sapply(eigs, min)
  )
  
  if (!quiet) {
    cat("\n", object$method, "\n\n")
    cat("data: ", object$data.name, "\n\n")
    cat("Chi-Sq (approx.) = ", object$statistic, "\n")
    cat("df:\t", object$parameter, "\n")
    fp <- format.pval(object$p.value, digits = max(1L, digits - 3L))
    cat("p-value:", fp, "\n\n")
    
    cat("log of Covariance determinants:\n")
    print(object$logDet, digits = digits)
    
    cat("\nEigenvalues:\n")
    print(eigs, digits = digits)
    
    cat("\nStatistics based on eigenvalues:\n")
    print(eigstats, digits = digits)
    
    if (cov) {
      cat("\nCovariance matrices:\n")
      print(object$cov, digits = digits)
      cat("\nPooled:\n")
      print(object$pooled, digits = digits)
    }
  }
  
  ret <- list(logDet = object$logDet, eigs = eigs, eigstats = eigstats)
  if (cov) ret <- c(ret, cov = list(object$cov))
  invisible(ret)
}
