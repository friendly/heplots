library(testthat)
library(ordr)

test_check("ordr")
