



#' @export
plot.pcadata <- function(x, ...) {
  plotPoints(x, ...)
}

#' @export
plot.pcoadata <- function(x, ...) {
  plotPoints(x, ...)
}

#' @export
plot.nmdsdata <- function(x, ...) {
  plotPoints(x, ...)
}

#' @export
plot.cdadata <- function(x, ...) {
  plotPoints(x, ...)
}

