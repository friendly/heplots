effectsHexsticker <- function(){
  browseURL(paste0("file://", system.file("doc", "effects-hex.pdf", package="effects")))
}