#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @import rlang
#' @importFrom lifecycle deprecated
## usethis namespace: end
NULL
