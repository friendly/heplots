# combines data frames correctly with space and no brackets

    Code
      .
    Output
        A   B            C
      1 1 x u apple orange
      2 2 y v banana grape
      3 3 z w cherry melon

---

    Code
      .
    Output
        A     B              C
      1 1 x (u) apple (orange)
      2 2 y (v) banana (grape)
      3 3 z (w) cherry (melon)

